﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\prouduct.mdf;Integrated Security=True");

        public SqlConnection Con { get => con; set => con = value; }

        public Form1()
        {
            InitializeComponent();
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
            Con.Open();
            disp_data();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Use parameterized queries to avoid SQL injection
            SqlCommand cmd = Con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO [Table] (Column1, Column2, Column3, Column4) VALUES (@val1, @val2, @val3, @val4)";

            // Replace 'TextBox1', 'TextBox2', etc., with the actual TextBox names used in your form
            cmd.Parameters.AddWithValue("@val1", textBox1.Text);
            cmd.Parameters.AddWithValue("@val2", textBox2.Text);
            cmd.Parameters.AddWithValue("@val3", textBox3.Text);
            cmd.Parameters.AddWithValue("@val4", textBox4.Text);

            cmd.ExecuteNonQuery();

            // Clear the textboxes
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";

            // Refresh the data grid view
            disp_data();
        }

        public void disp_data()
        {
            SqlCommand cmd = Con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM [Table]";
            cmd.ExecuteNonQuery();

          

       
        }
    }
}
